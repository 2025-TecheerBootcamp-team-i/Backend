# Lambda 이미지 리사이저 패키지
